/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bill.system;

import java.sql.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author jella
 */
public class BillSystem extends javax.swing.JFrame{

    /**
     * Creates new form BillSystem
     */
    static Connection conn = null;
    static Statement stmt = null;
    static String sql;
    int tid=0,tot=0;
    DefaultTableModel model;
    public BillSystem() {
        initComponents();
        this.setLocationRelativeTo(null);
        try{
                int s=0;
                conn = DB_Connection.getConn();
                }
        catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
        confirm.setEnabled(false);
        Report.setEnabled(false);
        Remove.setEnabled(false);
        getItems();
        getTSales();
        showDate();
        showTime();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        DateLabel = new javax.swing.JLabel();
        TimeLabel = new javax.swing.JLabel();
        QComboBox = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        confirm = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        BillTable = new javax.swing.JTable();
        addButton = new javax.swing.JButton();
        ItemComboBox = new javax.swing.JComboBox<>();
        AddItem = new javax.swing.JButton();
        UpdateCost = new javax.swing.JButton();
        RemoveItem = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        TotalLabel = new javax.swing.JLabel();
        Remove = new javax.swing.JButton();
        Report = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jLabel2.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N
        jLabel2.setText("Date:");

        jLabel3.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N
        jLabel3.setText("Time:");

        DateLabel.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N

        TimeLabel.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N

        QComboBox.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        QComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4" }));

        jLabel4.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N
        jLabel4.setText("Total todays Sales:");

        confirm.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        confirm.setText("Confirm Order");
        confirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmActionPerformed(evt);
            }
        });

        BillTable.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        BillTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "RemoveCheck", "Particulars", "Rate", "Quantity", "Amount"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Boolean.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(BillTable);

        addButton.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        addButton.setText("ADD TO ORDER");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        ItemComboBox.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        ItemComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemComboBoxActionPerformed(evt);
            }
        });

        AddItem.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        AddItem.setText("ADD ITEM");
        AddItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddItemActionPerformed(evt);
            }
        });

        UpdateCost.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        UpdateCost.setText("UPDATE COST");
        UpdateCost.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateCostActionPerformed(evt);
            }
        });

        RemoveItem.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        RemoveItem.setText("REMOVE ITEM");
        RemoveItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveItemActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N
        jLabel1.setText("Select Item:");

        jLabel5.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N
        jLabel5.setText("Select Quantity");

        TotalLabel.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N

        Remove.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        Remove.setText("Remove From Order");
        Remove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveActionPerformed(evt);
            }
        });

        Report.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        Report.setText("Generate Report");
        Report.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReportActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel6.setText("TAJ HOTEL BILLING SYSTEM");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(95, 95, 95)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TotalLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(UpdateCost)
                        .addComponent(RemoveItem, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(AddItem, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel1)
                                .addComponent(jLabel5))
                            .addGap(97, 97, 97)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(QComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(addButton)
                                        .addComponent(ItemComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(0, 0, Short.MAX_VALUE))))))
                .addGap(106, 106, 106)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(Remove)
                                .addGap(47, 47, 47)
                                .addComponent(confirm, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Report))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 531, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 95, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(DateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(TimeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(343, 343, 343)
                .addComponent(jLabel6)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addGap(67, 67, 67)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(ItemComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(QComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(41, 41, 41)
                        .addComponent(addButton)
                        .addGap(76, 76, 76)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(AddItem)
                            .addComponent(Remove)
                            .addComponent(confirm)
                            .addComponent(Report)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(RemoveItem)
                .addGap(18, 18, 18)
                .addComponent(UpdateCost)
                .addGap(61, 61, 61)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TotalLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TimeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public static void getItems()
    {
        ItemComboBox.removeAllItems();
        try{    
            stmt = conn.createStatement();
            sql = "SELECT item FROM ITEMS";
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next())
            {
               ItemComboBox.addItem(rs.getString("item"));
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e);
        }
    }
   public void getTSales()
   {
          
        Date d=new Date();
        SimpleDateFormat sobj=new SimpleDateFormat("YYYY-MM-dd");
        sql="SELECT TDATE FROM TRANSACTION WHERE TDATE='"+sobj.format(d).toString()+"'";
        String r="";
        int t=0;
        try 
        { 
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next())
            {
                r=rs.getString("TDATE");
            }
            if(r.equals(""))
            {
                TotalLabel.setText("0");
            }
            else
            {
                sql="SELECT AMOUNT FROM TRANSACTION WHERE TDATE='"+sobj.format(d).toString()+"'";
                rs=stmt.executeQuery(sql);
                while(rs.next())
                    t+=rs.getInt("AMOUNT");
            }
            TotalLabel.setText(t+"");
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,e);
        }
   }
    public double itemValue(String str,int quan){
        double rate;
        double k=0;
        try{    
            stmt = conn.createStatement();
            String sql = "SELECT COST FROM ITEMS WHERE item='"+str+"'";
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next())
            {
                k=rs.getDouble("COST");
            }
            rate=quan*k;
            return rate;
        }
        catch(Exception e){JOptionPane.showMessageDialog(null,e);}
        return 0;
    }
    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        model=(DefaultTableModel) BillTable.getModel();
        String name="";
        int quan;
        double amount;
        name=ItemComboBox.getSelectedItem().toString();
        quan=Integer.parseInt(QComboBox.getSelectedItem().toString());
        amount=itemValue(name,quan);
        model.addRow(new Object[]{false,name,(int)(amount/quan),quan,amount});
        confirm.setEnabled(true);
        Remove.setEnabled(true);
    }//GEN-LAST:event_addButtonActionPerformed

    private void ItemComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemComboBoxActionPerformed
        
    }//GEN-LAST:event_ItemComboBoxActionPerformed

    private void AddItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddItemActionPerformed
        AddItem a=new AddItem();
        a.setVisible(true);
    }//GEN-LAST:event_AddItemActionPerformed

    private void UpdateCostActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateCostActionPerformed
        ChangeCost c=new ChangeCost();
        c.setVisible(true);
    }//GEN-LAST:event_UpdateCostActionPerformed

    private void confirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmActionPerformed
        int c=JOptionPane.showConfirmDialog(this,"Do you want to confirm the order:'"+ItemComboBox.getSelectedItem().toString()+"'","Confirm",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE);
        if(c==JOptionPane.YES_OPTION)
        {
            Date d=new Date();
            SimpleDateFormat sobj=new SimpleDateFormat("YYYY-MM-dd");
            sql="SELECT TDATE FROM TRANSACTION WHERE TDATE='"+sobj.format(d).toString()+"'";
            String r="";
            try 
            {
                ResultSet rs=stmt.executeQuery(sql);
                while(rs.next())
                {
                    r=rs.getString("TDATE");
                }
                if(r.equals(""))
                {
                    tid=1;
                    getTSales();
                }
                else
                {
                    sql="SELECT MAX(TID) AS TID FROM TRANSACTION WHERE TDATE='"+sobj.format(d).toString()+"'";
                    rs=stmt.executeQuery(sql);
                    if(rs.next())
                    {
                        rs.last();
                        tid=rs.getInt("TID")+1;
                    }
                    getTSales();
                }
            }
            catch (SQLException e) {
                JOptionPane.showMessageDialog(null,e);
            }
            catch (Exception e) {
                JOptionPane.showMessageDialog(null,e);
            }
            try{
            for(int i=0;i<model.getRowCount();i++)
            {
                try{
                    sql="INSERT INTO TRANSACTION(TID,TDATE,TTIME,ITEM,QUANTITY,COST,AMOUNT) VALUES("+
                            tid+",'"+sobj.format(d).toString()+"','"+new SimpleDateFormat("hh:mm:ss").format(d)+"','"+
                            model.getValueAt(i,1).toString()+"',"+Integer.parseInt(model.getValueAt(i,3).toString())+","+
                            Double.parseDouble(model.getValueAt(i,2).toString())+","+Double.parseDouble(model.getValueAt(i,4).toString())+")";
                    stmt.executeUpdate(sql);
                }
                catch(Exception e)
                {
                    JOptionPane.showMessageDialog(null,"Order Unsuccessful....!");
                }
            }
            JOptionPane.showMessageDialog(null,"Order Success...!");
            getTSales();
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,e);
            }
            for (int i=0;i<model.getRowCount();i++) {
                   model.removeRow(i);
                   i--;
              }
            Report.setEnabled(true);
            confirm.setEnabled(false);
            Remove.setEnabled(false);
        }
        if(c==JOptionPane.NO_OPTION||c==JOptionPane.CANCEL_OPTION)
            return;
    }//GEN-LAST:event_confirmActionPerformed

    private void RemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveActionPerformed
        for (int i=0;i<model.getRowCount();i++) {
              Boolean checked=(Boolean)model.getValueAt(i,0);
              if (checked)
              {
                   model.removeRow(i);
                   i--;
              }
            if(model.getRowCount()==0)
            {
                confirm.setEnabled(false);
                Remove.setEnabled(false);
            }
        }
    }//GEN-LAST:event_RemoveActionPerformed

    private void RemoveItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveItemActionPerformed
        RemoveItem r=new RemoveItem();
        r.setVisible(true);
    }//GEN-LAST:event_RemoveItemActionPerformed

    private void ReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReportActionPerformed
        Date d=new Date();
        SimpleDateFormat sobj=new SimpleDateFormat("YYYY-MM-dd");
        try {
            InputStream input = new FileInputStream(new File("C:\\Users\\sumanth\\Documents\\Bill System\\src\\bill\\system\\invoice.jrxml"));
            JasperDesign jd=JRXmlLoader.load(input);
            Map<String,Object> param=new HashMap<>();
            sql="select SUM(AMOUNT) TOTAL from transaction where tid="+tid+" and tdate='"+sobj.format(d)+"'";
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next())
                tot=rs.getInt("TOTAL");
            param.put("tid1",tid);
            param.put("tdate",sobj.format(d).toString());
            param.put("Total",tot);
            JasperReport jr=JasperCompileManager.compileReport(jd);
            JasperPrint jp=  JasperFillManager.fillReport(jr,param,conn);
            JasperViewer.viewReport(jp,false);
            OutputStream os=new FileOutputStream(new File("C:\\Users\\sumanth\\Documents\\Reports\\invoce"+"of T"+Integer.toString(tid)+" on"+sobj.format(d)+".pdf"));
            JasperExportManager.exportReportToPdfStream(jp,os);
        }
        catch (JRException ex) {
            Logger.getLogger(BillSystem.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(BillSystem.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(BillSystem.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        Report.setEnabled(false);
    }//GEN-LAST:event_ReportActionPerformed
    
    public void showDate(){
        Date d=new Date();
        SimpleDateFormat sobj=new SimpleDateFormat("dd-MM-yyyy");
        DateLabel.setText(sobj.format(d));   
    }
    
    public void showTime(){
        new Timer(0,new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) { 
                Date d=new Date();
                SimpleDateFormat sobj=new SimpleDateFormat("hh:mm:ss a");
                TimeLabel.setText(sobj.format(d));   
            }
        }).start();    
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BillSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BillSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BillSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BillSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BillSystem().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddItem;
    private javax.swing.JTable BillTable;
    private javax.swing.JLabel DateLabel;
    private static javax.swing.JComboBox<String> ItemComboBox;
    private javax.swing.JComboBox<String> QComboBox;
    private javax.swing.JButton Remove;
    private javax.swing.JButton RemoveItem;
    private javax.swing.JButton Report;
    private javax.swing.JLabel TimeLabel;
    private javax.swing.JLabel TotalLabel;
    private javax.swing.JButton UpdateCost;
    private javax.swing.JButton addButton;
    private javax.swing.JButton confirm;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
